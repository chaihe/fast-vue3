// let type = process.argv.slice(2)[0];

// if (type === "--test") {
//   process.env.VUE_APP_BASE_API = "http://121.36.28.248:8195/api/v1/";
// }
// if (type == "--prod") {
//   process.env.VUE_APP_BASE_API = "http://zytech.org.cn/api/v1/";
// }

"use strict";
module.exports = {
  PROD_BASE_URL: '"https://juejin-game.bytedance.com"',
  TEST_BASE_URL: 'https://api.juejin.cn/user_api/v1/user/get'
};
