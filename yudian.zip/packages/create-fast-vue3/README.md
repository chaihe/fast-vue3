# create-fast-vue3

a scanffold to create vue3 project that use fast-vue3 template

## Usage

```bash
npm init fast-vue3
```
