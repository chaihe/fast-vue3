<template>
  <div class="common-layout">
    <el-container>
      <el-header class="bg-light-400 flex items-center">
        <div class="title font-bold text-3xl text-sky-700"> 玉殿 </div>
      </el-header>
      <el-container>
        <el-aside width="200px">
          <ul>
            <li class="my-5 mx-4">订单列表</li>
          </ul>
        </el-aside>
        <el-main>
          <div class="search flex items-center justify-start">
            <el-input style="width: 220px" v-model="yd_token" :placeholder="yd_token_txt" clearable />
            <el-input style="width: 150px" v-model="sell_uid" :placeholder="sell_uid_txt" clearable />
            <el-date-picker class="mr-5" v-model="day" type="date" placeholder="" :disabled-date="disabledDate" :shortcuts="shortcuts" />
            <el-button type="primary" @click="searchClick">查询</el-button>
          </div>
          <div class="list mt-5">
            <el-table :data="tableData" style="width: 100%">
              <el-table-column prop="date" label="Date" width="180" />
              <el-table-column prop="name" label="Name" width="180" />
              <el-table-column prop="address" label="Address" />
            </el-table>
          </div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup lang="ts">
  import { ref, onMounted } from 'vue';
  import { getOrderList } from '/@/api/user/index';
  const yd_token_txt = '请联系 柴智 或者 孙立军 录入';
  const sell_uid_txt = '请输入用户id';
  const day_txt = '请选择日期';
  const yd_token = ref('');
  const sell_uid = ref('');
  const day = ref('');
  const shortcuts = [
    {
      text: 'Today',
      value: new Date(),
    },
  ];
  const disabledDate = (time: Date) => {
    return time.getTime() > Date.now();
  };

  const searchClick = async () => {
    // if (yd_token.value === '') {
    //   ElMessage({
    //     message: yd_token_txt,
    //     type: 'warning',
    //   });
    //   return;
    // }
    // if (sell_uid.value === '') {
    //   ElMessage({
    //     message: sell_uid_txt,
    //     type: 'warning',
    //   });
    //   return;
    // }
    // if (day.value === '') {
    //   ElMessage({
    //     message: day_txt,
    //     type: 'warning',
    //   });
    //   return;
    // }
    const result = await getOrderList();
    console.log('result', result);
  };

  const tableData = [
    {
      date: '2016-05-03',
      name: 'Tom',
      address: 'No. 189, Grove St, Los Angeles',
    },
  ];

  onMounted(() => {
    console.log('onMounted');
  });
</script>

<style lang="less" scoped>
  .search > * {
    margin-right: 20px;
  }
</style>
