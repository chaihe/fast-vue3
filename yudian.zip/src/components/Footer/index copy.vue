<template>
  <SvgIcon name="svg-github" size="24" style="margin-right: 10px" />
</template>

<script setup lang="ts">
  import SvgIcon from '/@/components/SvgIcon/index.vue';
</script>

<style lang="less" scoped>
  .footer {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 240px;
    color: var(--color-text-2);
    text-align: center;
  }
</style>
