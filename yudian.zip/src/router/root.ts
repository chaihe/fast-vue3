export default [
  {
    path: '/',
    component: () => import('@/pages/login/index.vue'),
  },
];
